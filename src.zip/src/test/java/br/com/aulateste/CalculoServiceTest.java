package br.com.aulateste;

import br.com.aulateste.service.CalculoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.ArrayList;
import java.util.List;


@SpringBootTest
public class CalculoServiceTest {

    @Autowired
    private CalculoService calculoService;

    @Test
    @DisplayName("Funcao Listar soma")

    public void funcaoListaSoma() {
        List<Float> listaNumeros = new ArrayList<>();
        listaNumeros.add(1f);
        listaNumeros.add(2f);
        listaNumeros.add(3f);
        listaNumeros.add(4f);
        Assertions.assertEquals(10f,calculoService.Listasoma(listaNumeros));
        Assertions.assertNotEquals(12.5f,calculoService.Listasoma(listaNumeros));
    }

    @Test
    @DisplayName("Funcao Listar Media")
    public void funcaoListaMedia(){
        List<Float> listaMedia = new ArrayList<>();
        listaMedia.add(1F);
        listaMedia.add(2F);
        listaMedia.add(3F);
        listaMedia.add(4f);
        Assertions.assertEquals(2.5f,calculoService.ListMedia(listaMedia));
        Assertions.assertNotEquals(12.5f,calculoService.ListMedia(listaMedia));
    }

    @Test
    @DisplayName("Funcao Listar Maior Numero")
    public void funcaoBuscarMaiorNumero(){
        List<Float> listaNumeros = new ArrayList<>();
        listaNumeros.add(1f);
        listaNumeros.add(2f);
        listaNumeros.add(3f);
        listaNumeros.add(4f);
        Assertions.assertEquals(4f,calculoService.buscarMaiorNumero(listaNumeros));
        Assertions.assertNotEquals(12.5f,calculoService.buscarMaiorNumero(listaNumeros));

    }

    @Test
    @DisplayName("Funcao Listar Menor Numero")
    public void funcaoBuscarMenorNumero(){
        List<Float> listaNumeros = new ArrayList<>();
        listaNumeros.add(1f);
        listaNumeros.add(2f);
        listaNumeros.add(3f);
        listaNumeros.add(4f);
       Assertions.assertEquals(1f,calculoService.buscarMenorNumero(listaNumeros));
       Assertions.assertNotEquals(4f,calculoService.buscarMenorNumero(listaNumeros));
    }
}



