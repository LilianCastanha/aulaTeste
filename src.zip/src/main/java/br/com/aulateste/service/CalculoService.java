package br.com.aulateste.service;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalculoService {

    public float Listasoma(List<Float> lista) {
        float soma = 0;
        for (int i = 0; i < lista.size(); i++) {
            soma += lista.get(i);
        }
        return soma;
    }

    public float buscarMaiorNumero(List<Float> lista) {
        float maiorNumero = 0;

        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i) > maiorNumero) {
                maiorNumero = lista.get(i);
            }
        }
        return maiorNumero;
    }

    public float buscarMenorNumero(List<Float> lista) {
        float menorNumero = lista.get(0);
        for (int i = 0; i < lista.size(); i++) {
            if(lista.get(i) < 0) {
                menorNumero = lista.get(i);
            }
        }
        return menorNumero;
    }

    public float ListMedia(List<Float> lista) {
        float media = 0;
        for (int i = 0; i < lista.size(); i++) {
            media += lista.get(i);
        }
        return media / lista.size();
    }
}






