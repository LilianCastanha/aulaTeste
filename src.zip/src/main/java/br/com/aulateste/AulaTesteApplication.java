package br.com.aulateste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaTesteApplication {

    public static void main(String[] args) {
        SpringApplication.run(AulaTesteApplication.class, args);
    }

}
